# Campus Connect — launch-ready Android source

Campus Connect is a Kenya-focused, adults-only (18+) student matchmaking app for Chuka University, University of Embu and Meru University of Science and Technology.

## Included
- Supabase email/password authentication
- 18+ date-of-birth gate
- University selection and email verification step
- Profile + bio + up to 6 photos
- Moderated visibility gate
- Discovery, like/pass and mutual matches
- Realtime match chat
- Report and block controls
- Manual KES 50 M-Pesa activation flow
- Protected admin payment-review function
- Admin student-verification function
- RLS and security hardening in `supabase/schema.sql`
- Privacy/safety/terms screens

## Important deployment note
This repository is source-complete but cannot be truthfully called a published APK until it is connected to a real Supabase project, the SQL is deployed, an admin account is created, and the Android release is built/signed on a machine with Flutter + Android SDK.

## Supabase setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Create the `profile-photos` storage bucket as configured by the SQL.
4. Create your first user in the app.
5. Add that user's UUID to `public.admin_users` in the SQL editor.
6. Approve student verification from your protected admin workflow, then approve their payment.
7. Put the project's URL and anon key in `.env` using `.env.example`.

## Student verification
For the MVP, university selection + verified email + admin approval are used. Do not assume that any ordinary email proves student status. Before public launch, configure the exact institutional domains/verification process for each participating university and review them periodically with the universities.

## M-Pesa
The current MVP intentionally uses manual payment: the user sends KES 50 to the configured receiver and enters the transaction code. Never ask for or store an M-Pesa PIN. For a real commercial launch, replace this with a registered Till/Paybill and server-side STK Push/Daraja integration.

## Android build
On a machine with Flutter installed:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

If the Android platform folder is missing, run `flutter create --platforms=android .` once, then repeat the commands above.

## Before Play Store launch
- Connect and test production Supabase
- Confirm institutional student verification with each university
- Replace manual M-Pesa with a proper business payment channel
- Configure Play Console, privacy policy URL, terms, data safety form and account deletion process
- Add production moderation/admin dashboard and incident escalation
- Test Android 16 and lower supported Android versions
- Build and sign the release APK/AAB with a private keystore

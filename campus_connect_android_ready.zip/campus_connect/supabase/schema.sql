-- Campus Connect MVP database schema
-- Run in Supabase SQL Editor.

create extension if not exists "pgcrypto";

create type public.verification_status as enum (
  'pending', 'email_verified', 'manual_review', 'approved', 'rejected'
);

create type public.account_status as enum (
  'pending', 'active', 'suspended', 'banned', 'deleted'
);

create type public.swipe_action as enum ('like', 'pass');

create type public.match_status as enum ('active', 'unmatched', 'blocked');

create type public.payment_type as enum ('activation', 'subscription', 'premium_feature');

create type public.payment_status as enum ('pending', 'paid', 'failed', 'refunded');

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  phone text,
  date_of_birth date not null,
  is_adult boolean generated always as ((date_of_birth <= (current_date - interval '18 years')::date)) stored,
  university text not null check (university in (
    'Chuka University',
    'University of Embu',
    'Meru University of Science and Technology'
  )),
  verification_status public.verification_status not null default 'pending',
  account_status public.account_status not null default 'pending',
  activation_paid boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.profiles (
  user_id uuid primary key references public.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 40),
  campus text,
  course text,
  year_of_study integer check (year_of_study between 1 and 10),
  bio text default '' check (char_length(bio) <= 500),
  gender text,
  interested_in text[],
  intentions text[],
  interests text[],
  is_visible boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.photos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  image_path text not null,
  position integer not null default 0,
  is_approved boolean not null default false,
  created_at timestamptz not null default now(),
  unique(user_id, position)
);

create table public.swipes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  target_user_id uuid not null references public.users(id) on delete cascade,
  action public.swipe_action not null,
  created_at timestamptz not null default now(),
  unique(user_id, target_user_id),
  check (user_id <> target_user_id)
);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  user_one_id uuid not null references public.users(id) on delete cascade,
  user_two_id uuid not null references public.users(id) on delete cascade,
  status public.match_status not null default 'active',
  matched_at timestamptz not null default now(),
  check (user_one_id < user_two_id),
  unique(user_one_id, user_two_id)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  sender_id uuid not null references public.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  payment_type public.payment_type not null,
  amount numeric(12,2) not null check (amount >= 0),
  currency text not null default 'KES',
  status public.payment_status not null default 'pending',
  provider text not null,
  transaction_reference text unique,
  created_at timestamptz not null default now()
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.users(id) on delete cascade,
  reported_user_id uuid not null references public.users(id) on delete cascade,
  reason text not null,
  description text,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  check (reporter_id <> reported_user_id)
);

create table public.blocks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  blocked_user_id uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, blocked_user_id),
  check (user_id <> blocked_user_id)
);

-- Match creation: run after a new LIKE is inserted.
create or replace function public.create_match_on_mutual_like()
returns trigger
language plpgsql
security definer
as $$
declare
  first_user uuid;
  second_user uuid;
begin
  if new.action <> 'like' then
    return new;
  end if;

  if exists (
    select 1 from public.swipes s
    where s.user_id = new.target_user_id
      and s.target_user_id = new.user_id
      and s.action = 'like'
  ) then
    if new.user_id < new.target_user_id then
      first_user := new.user_id;
      second_user := new.target_user_id;
    else
      first_user := new.target_user_id;
      second_user := new.user_id;
    end if;

    insert into public.matches (user_one_id, user_two_id)
    values (first_user, second_user)
    on conflict (user_one_id, user_two_id) do nothing;
  end if;

  return new;
end;
$$;

create trigger on_mutual_like
after insert or update of action on public.swipes
for each row execute function public.create_match_on_mutual_like();

alter table public.users enable row level security;
alter table public.profiles enable row level security;
alter table public.photos enable row level security;
alter table public.swipes enable row level security;
alter table public.matches enable row level security;
alter table public.messages enable row level security;
alter table public.payments enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;

-- Starter RLS policies. Tighten these further before production.
create policy "users read own row" on public.users
for select using (auth.uid() = id);

create policy "users update own row" on public.users
for update using (auth.uid() = id);

create policy "profiles read discoverable approved adults" on public.profiles
for select using (
  user_id = auth.uid() or exists (
    select 1 from public.users u
    where u.id = profiles.user_id
      and u.is_adult = true
      and u.verification_status = 'approved'
      and u.account_status = 'active'
  )
);

create policy "users manage own profile" on public.profiles
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "users manage own swipes" on public.swipes
for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "users view own matches" on public.matches
for select using (auth.uid() in (user_one_id, user_two_id));

create policy "users view match messages" on public.messages
for select using (
  exists (
    select 1 from public.matches m
    where m.id = messages.match_id
      and m.status = 'active'
      and auth.uid() in (m.user_one_id, m.user_two_id)
  )
);

create policy "users send messages to own matches" on public.messages
for insert with check (
  auth.uid() = sender_id and exists (
    select 1 from public.matches m
    where m.id = match_id
      and m.status = 'active'
      and auth.uid() in (m.user_one_id, m.user_two_id)
  )
);


-- Production hardening helper:
-- Discoverability should only be granted by trusted backend logic after all
-- required checks (18+, verification, payment) are satisfied.
create or replace function public.activate_discoverability(target_user_id uuid)
returns void
language plpgsql
security definer
as $$
begin
  if not exists (
    select 1
    from public.users
    where id = target_user_id
      and is_adult = true
      and verification_status in ('approved')
      and account_status = 'active'
      and activation_paid = true
  ) then
    raise exception 'User is not eligible for discovery';
  end if;

  update public.profiles
  set is_visible = true,
      updated_at = now()
  where user_id = target_user_id;
end;
$$;


-- PROFILE PHOTO STORAGE
-- Create a bucket named profile-photos in the Supabase dashboard.
-- Keep uploads restricted to the owner; choose public URLs only if your
-- moderation/privacy model permits it.
insert into storage.buckets (id, name, public)
values ('profile-photos', 'profile-photos', true)
on conflict (id) do nothing;

create policy "users upload own profile photos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'profile-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "users delete own profile photos"
on storage.objects for delete to authenticated
using (
  bucket_id = 'profile-photos'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "public read profile photos"
on storage.objects for select
using (bucket_id = 'profile-photos');

-- DISCOVERY RPC
-- Only returns profiles eligible for discovery. Excludes the current user,
-- already-swiped users and blocked relationships.
create or replace function public.get_discovery_profiles()
returns table (
  user_id uuid,
  display_name text,
  age integer,
  university text,
  bio text,
  photo_urls text[]
)
language sql
security definer
set search_path = public
as $$
  select
    p.user_id,
    p.display_name,
    extract(year from age(current_date, u.date_of_birth))::integer as age,
    u.university,
    p.bio,
    coalesce(
      array_agg(
        case when ph.image_path is not null
        then (select url from storage.get_public_url('profile-photos', ph.image_path))
        end
        order by ph.position
      ) filter (where ph.image_path is not null),
      array[]::text[]
    ) as photo_urls
  from public.profiles p
  join public.users u on u.id = p.user_id
  left join public.photos ph
    on ph.user_id = p.user_id and ph.is_approved = true
  where p.user_id <> auth.uid()
    and p.is_visible = true
    and u.is_adult = true
    and u.verification_status = 'approved'
    and u.account_status = 'active'
    and u.activation_paid = true
    and not exists (
      select 1 from public.swipes s
      where s.user_id = auth.uid() and s.target_user_id = p.user_id
    )
    and not exists (
      select 1 from public.blocks b
      where (b.user_id = auth.uid() and b.blocked_user_id = p.user_id)
         or (b.user_id = p.user_id and b.blocked_user_id = auth.uid())
    )
  group by p.user_id, p.display_name, u.date_of_birth, u.university, p.bio
  order by random()
  limit 50;
$$;

-- MATCH LIST RPC
create or replace function public.get_my_matches()
returns table (
  match_id uuid,
  other_user_id uuid,
  display_name text,
  university text
)
language sql
security definer
set search_path = public
as $$
  select
    m.id as match_id,
    case when m.user_one_id = auth.uid() then m.user_two_id else m.user_one_id end as other_user_id,
    p.display_name,
    u.university
  from public.matches m
  join public.profiles p
    on p.user_id = case when m.user_one_id = auth.uid() then m.user_two_id else m.user_one_id end
  join public.users u on u.id = p.user_id
  where auth.uid() in (m.user_one_id, m.user_two_id)
    and m.status = 'active'
  order by m.matched_at desc;
$$;

-- SECURITY NOTE:
-- In production, photo approval and profile visibility must be changed only
-- by trusted moderation/backend logic. Do not grant ordinary clients a path
-- to mark photos approved or set accounts active/paid.


-- M-PESA PAYMENT SUPPORT
alter table public.payments
  add column if not exists plan text not null default 'activation',
  add column if not exists phone_number_masked text,
  add column if not exists checkout_request_id text unique,
  add column if not exists merchant_request_id text,
  add column if not exists mpesa_receipt text,
  add column if not exists provider_payload jsonb,
  add column if not exists paid_at timestamptz;

-- Users may see only their own payment records.
alter table public.payments enable row level security;

drop policy if exists "users read own payments" on public.payments;
create policy "users read own payments"
on public.payments for select to authenticated
using (user_id = auth.uid());

-- Do not allow ordinary Android clients to mark payments successful.
drop policy if exists "clients create payments" on public.payments;
create policy "clients create payments"
on public.payments for insert to authenticated
with check (false);

-- Realtime payment status refresh.
alter publication supabase_realtime add table public.payments;

-- TEMPORARY MANUAL M-PESA PAYMENT FLOW
create table if not exists public.manual_payment_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount > 0), currency text not null default 'KES',
  receiver_reference text not null, sender_phone_masked text,
  transaction_code text not null unique,
  status text not null default 'pending_review' check (status in ('pending_review','approved','rejected')),
  reviewed_by uuid references auth.users(id), reviewed_at timestamptz, reviewer_note text,
  created_at timestamptz not null default now()
);
alter table public.manual_payment_requests enable row level security;
drop policy if exists "users submit own manual payment requests" on public.manual_payment_requests;
create policy "users submit own manual payment requests" on public.manual_payment_requests for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "users read own manual payment requests" on public.manual_payment_requests;
create policy "users read own manual payment requests" on public.manual_payment_requests for select to authenticated using (user_id = auth.uid());
alter publication supabase_realtime add table public.manual_payment_requests;
create or replace function public.review_manual_payment(request_id uuid, approve boolean, note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare request_user_id uuid;
begin
 select user_id into request_user_id from public.manual_payment_requests where id=request_id and status='pending_review' for update;
 if request_user_id is null then raise exception 'Payment request not found or already reviewed'; end if;
 update public.manual_payment_requests set status=case when approve then 'approved' else 'rejected' end, reviewed_by=auth.uid(), reviewed_at=now(), reviewer_note=note where id=request_id;
 if approve then update public.users set activation_paid=true, account_status='active' where id=request_user_id; end if;
end; $$;

-- =========================================================
-- PRODUCTION HARDENING / ADMIN / DISCOVERY RPCS
-- =========================================================

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.admin_users where user_id = auth.uid());
$$;

-- Ordinary clients cannot mutate protected account flags.
drop policy if exists "users update own row" on public.users;
drop policy if exists "users read own row" on public.users;
create policy "users read own row" on public.users
for select to authenticated using (auth.uid() = id);

-- Profile photos: owner can manage, but only approved photos are discoverable.
drop policy if exists "photos owner manage" on public.photos;
create policy "photos owner manage" on public.photos
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id and is_approved = false);

-- Reports and blocks are private to the reporting/blocking user.
drop policy if exists "reports owner insert" on public.reports;
create policy "reports owner insert" on public.reports
for insert to authenticated with check (auth.uid() = reporter_id);
drop policy if exists "reports owner read" on public.reports;
create policy "reports owner read" on public.reports
for select to authenticated using (auth.uid() = reporter_id);
drop policy if exists "blocks owner manage" on public.blocks;
create policy "blocks owner manage" on public.blocks
for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Tight manual-payment insert policy: clients cannot choose a fake amount/receiver.
drop policy if exists "users submit own manual payment requests" on public.manual_payment_requests;
create policy "users submit own manual payment requests" on public.manual_payment_requests
for insert to authenticated
with check (
  user_id = auth.uid()
  and amount = 50
  and currency = 'KES'
  and receiver_reference = '0725657443'
  and status = 'pending_review'
  and reviewed_by is null
  and reviewed_at is null
);

-- Admin-only payment review.
create or replace function public.review_manual_payment(request_id uuid, approve boolean, note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare
  request_user_id uuid;
begin
  if not public.is_admin() then
    raise exception 'Not authorized';
  end if;
  select user_id into request_user_id
  from public.manual_payment_requests
  where id = request_id and status = 'pending_review'
  for update;
  if request_user_id is null then raise exception 'Payment request not found or already reviewed'; end if;

  if approve and not exists (
    select 1 from public.users
    where id = request_user_id and is_adult = true and verification_status = 'approved'
  ) then
    raise exception 'Student verification must be approved before payment activation';
  end if;

  update public.manual_payment_requests
  set status = case when approve then 'approved' else 'rejected' end,
      reviewed_by = auth.uid(), reviewed_at = now(), reviewer_note = note
  where id = request_id;

  if approve then
    update public.users
    set activation_paid = true, account_status = 'active'
    where id = request_user_id;
    update public.profiles set is_visible = true where user_id = request_user_id;
  end if;
end; $$;

create or replace function public.admin_pending_manual_payments()
returns table (
  id uuid, user_id uuid, amount integer, currency text, sender_phone_masked text,
  transaction_code text, status text, created_at timestamptz, university text, email text, display_name text
)
language sql stable security definer set search_path = public as $$
  select r.id, r.user_id, r.amount, r.currency, r.sender_phone_masked, r.transaction_code,
         r.status, r.created_at, u.university, u.email, p.display_name
  from public.manual_payment_requests r
  join public.users u on u.id = r.user_id
  left join public.profiles p on p.user_id = r.user_id
  where public.is_admin() and r.status = 'pending_review'
  order by r.created_at asc;
$$;

create or replace function public.admin_review_user(target_user_id uuid, approve boolean)
returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not authorized'; end if;
  update public.users
  set verification_status = case when approve then 'approved' else 'rejected' end,
      account_status = case when approve and activation_paid then 'active' else account_status end
  where id = target_user_id and is_adult = true;
  if approve then
    update public.profiles set is_visible = true where profiles.user_id = target_user_id and exists (select 1 from public.users x where x.id = target_user_id and x.activation_paid = true and x.account_status = 'active');
  end if;
end; $$;

-- Discovery runs with controlled server-side checks so ordinary clients never need
-- direct read access to every user's private users row.
create or replace function public.get_discoverable_profiles()
returns table (
  user_id uuid, display_name text, university text, age integer, bio text, photo_paths text[]
)
language sql stable security definer set search_path = public as $$
  select u.id,
         p.display_name,
         u.university,
         extract(year from age(current_date, u.date_of_birth))::integer as age,
         p.bio,
         coalesce(array_agg(distinct image_path) filter (where image_path is not null), '{}')::text[] as photo_paths
  from public.users u
  join public.profiles p on p.user_id = u.id
  left join lateral (
    select ph.image_path
    from public.photos ph
    where ph.user_id = u.id and ph.is_approved = true
    order by ph.position
    limit 6
  ) photo on true
  where u.id <> auth.uid()
    and u.is_adult = true
    and u.verification_status = 'approved'
    and u.account_status = 'active'
    and u.activation_paid = true
    and p.is_visible = true
    and not exists (select 1 from public.blocks b where b.user_id = auth.uid() and b.blocked_user_id = u.id)
    and not exists (select 1 from public.blocks b where b.user_id = u.id and b.blocked_user_id = auth.uid())
    and not exists (select 1 from public.swipes s where s.user_id = auth.uid() and s.target_user_id = u.id)
  group by u.id, p.display_name, u.university, u.date_of_birth, p.bio
  order by random()
  limit 50;
$$;

create or replace function public.get_my_matches()
returns table (
  match_id uuid, user_id uuid, display_name text, university text, bio text
)
language sql stable security definer set search_path = public as $$
  select m.id,
         case when m.user_one_id = auth.uid() then m.user_two_id else m.user_one_id end,
         p.display_name, u.university, p.bio
  from public.matches m
  join public.users u on u.id = case when m.user_one_id = auth.uid() then m.user_two_id else m.user_one_id end
  join public.profiles p on p.user_id = u.id
  where m.status = 'active' and auth.uid() in (m.user_one_id, m.user_two_id)
  order by m.matched_at desc;
$$;

-- Realtime for chat.
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.matches;

create or replace function public.admin_pending_users()
returns table (user_id uuid, email text, university text, verification_status text, account_status text, created_at timestamptz, display_name text)
language sql stable security definer set search_path = public as $$
  select u.id, u.email, u.university, u.verification_status::text, u.account_status::text, u.created_at, p.display_name
  from public.users u
  left join public.profiles p on p.user_id = u.id
  where public.is_admin()
    and u.verification_status in ('email_verified','manual_review')
    and u.is_adult = true
  order by u.created_at asc;
$$;

-- Final client-write restrictions for onboarding/profile data.
drop policy if exists "users insert own row" on public.users;
create policy "users insert own row" on public.users
for insert to authenticated
with check (
  auth.uid() = id
  and activation_paid = false
  and account_status = 'pending'
  and verification_status = 'pending'
);

-- Recreate profile policies so clients cannot self-publish.
drop policy if exists "users manage own profile" on public.profiles;
create policy "users read own profile" on public.profiles
for select to authenticated using (auth.uid() = user_id);
create policy "users insert own unpublished profile" on public.profiles
for insert to authenticated with check (auth.uid() = user_id and is_visible = false);
create policy "users update own unpublished profile" on public.profiles
for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id and is_visible = false);

create or replace function public.mark_email_verified()
returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from auth.users where id = auth.uid() and email_confirmed_at is not null) then
    raise exception 'Email is not confirmed';
  end if;
  update public.users
  set verification_status = 'email_verified'
  where id = auth.uid() and verification_status = 'pending';
end; $$;

create or replace function public.admin_pending_photos()
returns table (id uuid, user_id uuid, image_path text, position integer, created_at timestamptz, display_name text, university text)
language sql stable security definer set search_path = public as $$
  select ph.id, ph.user_id, ph.image_path, ph.position, ph.created_at, p.display_name, u.university
  from public.photos ph
  join public.users u on u.id = ph.user_id
  left join public.profiles p on p.user_id = ph.user_id
  where public.is_admin() and ph.is_approved = false
  order by ph.created_at asc;
$$;

create or replace function public.admin_review_photo(photo_id uuid, approve boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not authorized'; end if;
  update public.photos set is_approved = approve where id = photo_id;
end; $$;

-- Final read restrictions for profile/photo data.
drop policy if exists "profiles read discoverable approved adults" on public.profiles;
create policy "profiles read discoverable approved adults" on public.profiles
for select to authenticated using (
  user_id = auth.uid() or exists (
    select 1 from public.users u
    where u.id = profiles.user_id
      and u.is_adult = true
      and u.verification_status = 'approved'
      and u.account_status = 'active'
      and u.activation_paid = true
      and profiles.is_visible = true
  )
);

drop policy if exists "photos owner read" on public.photos;
create policy "photos owner read" on public.photos
for select to authenticated using (auth.uid() = user_id);

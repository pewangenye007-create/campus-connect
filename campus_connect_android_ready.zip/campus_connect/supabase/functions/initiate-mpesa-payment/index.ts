import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });

function requireEnv(name: string) {
  const value = Deno.env.get(name);
  if (!value) throw new Error(`Missing server secret: ${name}`);
  return value;
}

async function getDarajaToken() {
  const key = requireEnv("MPESA_CONSUMER_KEY");
  const secret = requireEnv("MPESA_CONSUMER_SECRET");
  const auth = btoa(`${key}:${secret}`);

  const response = await fetch(requireEnv("MPESA_OAUTH_URL"), {
    headers: { Authorization: `Basic ${auth}` },
  });
  if (!response.ok) throw new Error("Could not authenticate with M-Pesa.");
  return (await response.json()).access_token as string;
}

serve(async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const supabaseUrl = requireEnv("SUPABASE_URL");
    const anonKey = requireEnv("SUPABASE_ANON_KEY");
    const admin = createClient(
      supabaseUrl,
      requireEnv("SUPABASE_SERVICE_ROLE_KEY"),
    );
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json();
    const phone = String(body.phone_number ?? "");
    const amount = Number(body.amount);
    const plan = String(body.plan ?? "activation");

    if (!/^254[17]\d{8}$/.test(phone)) {
      return json({ error: "Invalid Kenyan mobile number." }, 400);
    }
    if (!Number.isInteger(amount) || amount < 1) {
      return json({ error: "Invalid payment amount." }, 400);
    }

    // IMPORTANT: Keep prices server-controlled. Do not trust an arbitrary
    // amount from the Android client.
    const allowedPrices: Record<string, number> = {
      activation: Number(requireEnv("MPESA_ACTIVATION_AMOUNT")),
      premium: Number(requireEnv("MPESA_PREMIUM_AMOUNT")),
    };
    if (allowedPrices[plan] !== amount) {
      return json({ error: "Invalid payment amount for selected plan." }, 400);
    }

    const timestamp = new Date()
      .toISOString()
      .replace(/[-:TZ.]/g, "")
      .slice(0, 14);

    const shortcode = requireEnv("MPESA_SHORTCODE");
    const passkey = requireEnv("MPESA_PASSKEY");
    const password = btoa(`${shortcode}${passkey}${timestamp}`);
    const callbackUrl = requireEnv("MPESA_CALLBACK_URL");

    const token = await getDarajaToken();

    const stkResponse = await fetch(requireEnv("MPESA_STK_URL"), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        BusinessShortCode: shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: "CustomerPayBillOnline",
        Amount: amount,
        PartyA: phone,
        PartyB: shortcode,
        PhoneNumber: phone,
        CallBackURL: callbackUrl,
        AccountReference: `CC-${user.id.slice(0, 8)}`,
        TransactionDesc: `Campus Connect ${plan}`,
      }),
    });

    const result = await stkResponse.json();
    if (!stkResponse.ok || result.ResponseCode !== "0") {
      return json({
        error: result.errorMessage ?? result.ResponseDescription ?? "M-Pesa request failed.",
      }, 400);
    }

    const { data: payment, error } = await admin.from("payments").insert({
      user_id: user.id,
      amount,
      currency: "KES",
      provider: "mpesa",
      status: "pending",
      plan,
      phone_number_masked: `*******${phone.slice(-3)}`,
      checkout_request_id: result.CheckoutRequestID,
      merchant_request_id: result.MerchantRequestID,
    }).select().single();

    if (error) throw error;

    return json({
      success: true,
      payment_id: payment.id,
      checkout_request_id: result.CheckoutRequestID,
      message: "STK Push sent. Enter your M-Pesa PIN on your phone.",
    });
  } catch (error) {
    console.error(error);
    return json({ error: String(error.message ?? error) }, 500);
  }
});

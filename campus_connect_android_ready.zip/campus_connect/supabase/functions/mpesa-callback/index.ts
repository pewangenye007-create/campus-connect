import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    const payload = await req.json();
    const callback = payload?.Body?.stkCallback;
    const checkoutId = callback?.CheckoutRequestID;
    const resultCode = Number(callback?.ResultCode);

    if (!checkoutId) {
      return new Response(JSON.stringify({ ResultCode: 1, ResultDesc: "Invalid callback" }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    const { data: payment } = await admin
      .from("payments")
      .select()
      .eq("checkout_request_id", checkoutId)
      .maybeSingle();

    if (!payment) {
      return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    if (resultCode === 0) {
      const items = callback.CallbackMetadata?.Item ?? [];
      const receipt = items.find((x: any) => x.Name === "MpesaReceiptNumber")?.Value ?? null;

      await admin.from("payments").update({
        status: "successful",
        mpesa_receipt: receipt,
        provider_payload: payload,
        paid_at: new Date().toISOString(),
      }).eq("id", payment.id);

      // Payment success alone is not enough to bypass student/adult checks.
      await admin.from("users").update({
        activation_paid: true,
        account_status: "active",
      }).eq("id", payment.user_id);
    } else {
      await admin.from("payments").update({
        status: "failed",
        provider_payload: payload,
      }).eq("id", payment.id);
    }

    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ ResultCode: 0, ResultDesc: "Accepted" }), {
      headers: { "Content-Type": "application/json" },
    });
  }
});

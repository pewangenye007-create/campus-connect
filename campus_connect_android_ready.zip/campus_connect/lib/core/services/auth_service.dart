import 'package:supabase_flutter/supabase_flutter.dart';

class AuthService {
  static final _client = Supabase.instance.client;
  static Stream<AuthState> get authStateChanges => _client.auth.onAuthStateChange;
  static User? get currentUser => _client.auth.currentUser;

  static Future<void> signUp({required String email, required String password}) async {
    final response = await _client.auth.signUp(email: email, password: password, emailRedirectTo: null);
    if (response.user == null) throw Exception('Could not create the account.');
  }

  static Future<void> signIn({required String email, required String password}) async {
    await _client.auth.signInWithPassword(email: email.trim(), password: password);
  }

  static Future<void> resendVerificationEmail(String email) async {
    await _client.auth.resend(type: OtpType.signup, email: email);
  }

  static Future<void> signOut() => _client.auth.signOut();

  static Future<void> createUserRecord({required DateTime dateOfBirth, required String university}) async {
    final user = currentUser;
    if (user == null) throw Exception('Please log in again.');
    await _client.from('users').upsert({
      'id': user.id,
      'email': user.email,
      'date_of_birth': dateOfBirth.toIso8601String().substring(0, 10),
      'university': university,
      'verification_status': 'pending',
    });
  }

  static Future<void> markEmailVerified() async {
    await _client.rpc('mark_email_verified');
  }

  static Future<void> saveProfile({required String displayName, required String bio}) async {
    final user = currentUser;
    if (user == null) throw Exception('Please log in again.');
    await _client.from('profiles').upsert({
      'user_id': user.id,
      'display_name': displayName.trim(),
      'bio': bio.trim(),
      'is_visible': false,
    });
  }

  static Future<Map<String, dynamic>?> getMyUserRecord() async {
    final user = currentUser;
    if (user == null) return null;
    final rows = await _client.from('users').select().eq('id', user.id).limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }


  static Future<bool> isAdmin() async {
    final result = await _client.rpc('is_admin');
    return result == true;
  }

  static Future<Map<String, dynamic>?> getMyProfile() async {
    final user = currentUser;
    if (user == null) return null;
    final rows = await _client.from('profiles').select().eq('user_id', user.id).limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }
}

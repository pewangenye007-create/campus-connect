import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_service.dart';

class SocialService {
  static final _client = Supabase.instance.client;

  static Future<List<Map<String, dynamic>>> getDiscoveryProfiles() async {
    final data = await _client.rpc('get_discoverable_profiles');
    return (data as List).map((e) {
      final row = Map<String, dynamic>.from(e);
      final paths = List<String>.from(row['photo_paths'] ?? const []);
      row['photo_urls'] = paths.map((path) => _client.storage.from('profile-photos').getPublicUrl(path)).toList();
      return row;
    }).toList();
  }

  static Future<void> swipe({required String targetUserId, required String action}) async {
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    await _client.from('swipes').upsert({
      'user_id': me.id,
      'target_user_id': targetUserId,
      'action': action,
    }, onConflict: 'user_id,target_user_id');
  }

  static Future<List<Map<String, dynamic>>> getMatches() async {
    final data = await _client.rpc('get_my_matches');
    return (data as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Stream<List<Map<String, dynamic>>> messagesStream(String matchId) {
    return _client.from('messages').stream(primaryKey: ['id']).eq('match_id', matchId).order('created_at').map(
      (rows) => rows.map((e) => Map<String, dynamic>.from(e)).toList(),
    );
  }

  static Future<void> sendMessage({required String matchId, required String content}) async {
    final text = content.trim();
    if (text.isEmpty || text.length > 2000) return;
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    await _client.from('messages').insert({'match_id': matchId, 'sender_id': me.id, 'content': text});
  }

  static Future<List<Map<String, dynamic>>> getMyPhotos() async {
    final me = AuthService.currentUser;
    if (me == null) return [];
    final rows = await _client.from('photos').select().eq('user_id', me.id).order('position');
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> uploadProfilePhoto(File file, int position) async {
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    final path = '${me.id}/$position-${DateTime.now().millisecondsSinceEpoch}.jpg';
    await _client.storage.from('profile-photos').upload(path, file, fileOptions: const FileOptions(upsert: false));
    await _client.from('photos').insert({'user_id': me.id, 'image_path': path, 'position': position, 'is_approved': false});
  }

  static Future<void> deletePhoto(Map<String, dynamic> photo) async {
    final path = photo['image_path'] as String;
    await _client.storage.from('profile-photos').remove([path]);
    await _client.from('photos').delete().eq('id', photo['id']);
  }

  static Future<void> blockUser(String userId) async {
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    await _client.from('blocks').upsert({'user_id': me.id, 'blocked_user_id': userId});
  }

  static Future<void> reportUser({required String userId, required String reason, String? description}) async {
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    await _client.from('reports').insert({
      'reporter_id': me.id,
      'reported_user_id': userId,
      'reason': reason,
      'description': description?.trim(),
    });
  }
}

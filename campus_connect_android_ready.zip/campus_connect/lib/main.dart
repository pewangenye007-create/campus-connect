import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await dotenv.load(fileName: '.env');
  } catch (_) {
    // First launch before local .env setup: keep the app from crashing with a
    // confusing missing-asset exception. A configured Supabase project is
    // still required for authentication and live data.
  }

  final url = dotenv.env['SUPABASE_URL'] ?? '';
  final anonKey = dotenv.env['SUPABASE_ANON_KEY'] ?? '';
  if (url.isEmpty || anonKey.isEmpty) {
    runApp(const _ConfigurationRequiredApp());
    return;
  }

  await Supabase.initialize(url: url, anonKey: anonKey);
  runApp(const CampusConnectApp());
}

class _ConfigurationRequiredApp extends StatelessWidget {
  const _ConfigurationRequiredApp();
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: const [
        Icon(Icons.settings_outlined, size: 64),
        SizedBox(height: 16),
        Text('Campus Connect needs configuration', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        SizedBox(height: 10),
        Text('Create a .env file from .env.example and add your Supabase URL and anon key before using the live app.', textAlign: TextAlign.center),
      ])),
    ),
  ));
}

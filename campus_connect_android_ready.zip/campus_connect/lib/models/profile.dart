class Profile {
  final String userId;
  final String displayName;
  final String university;
  final int age;
  final String bio;

  const Profile({
    required this.userId,
    required this.displayName,
    required this.university,
    required this.age,
    required this.bio,
  });
}

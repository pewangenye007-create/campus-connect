import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Campus Connect release package has the expected product name', () {
    expect('Campus Connect', isNotEmpty);
  });
}

package com.campusconnect
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()

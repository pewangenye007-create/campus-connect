import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_service.dart';

class ManualPaymentService {
  static const receiverPhone = '0725657443';
  static Future<int> getActivationFee() async {
    final value = await _client.rpc('get_activation_fee');
    return (value as num).toInt();
  }
  static final _client = Supabase.instance.client;

  static Future<void> submit({required String transactionCode, required String senderPhone}) async {
    final me = AuthService.currentUser;
    if (me == null) throw Exception('Please log in again.');
    final code = transactionCode.trim().toUpperCase();
    final phone = senderPhone.trim();
    if (code.length < 6) throw Exception('Enter the M-Pesa transaction code.');
    if (phone.length < 9) throw Exception('Enter the phone number used to pay.');
    final amount = await getActivationFee();
    await _client.from('manual_payment_requests').insert({
      'user_id': me.id,
      'amount': amount,
      'currency': 'KES',
      'receiver_reference': receiverPhone,
      'sender_phone_masked': phone.length > 4 ? '${phone.substring(0, phone.length - 4)}****' : '****',
      'transaction_code': code,
    });
  }

  static Future<List<Map<String, dynamic>>> adminPending() async {
    final data = await _client.rpc('admin_pending_manual_payments');
    return (data as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> review({required String requestId, required bool approve, String? note}) async {
    await _client.rpc('review_manual_payment', params: {'request_id': requestId, 'approve': approve, 'note': note});
  }

  static Stream<List<Map<String, dynamic>>> myRequests() {
    final me = AuthService.currentUser;
    if (me == null) return const Stream.empty();
    return _client.from('manual_payment_requests').stream(primaryKey: ['id']).eq('user_id', me.id).order('created_at', ascending: false).map(
      (rows) => rows.map((e) => Map<String, dynamic>.from(e)).toList(),
    );
  }
}

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/services/auth_service.dart';
import 'core/services/social_service.dart';
import 'core/services/manual_payment_service.dart';
import 'core/services/payment_service.dart';

class CampusConnectApp extends StatelessWidget {
  const CampusConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Campus Connect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class OnboardingData {
  String? email;
  String? password;
  DateTime? dateOfBirth;
  String? university;
  String? displayName;
  String? bio;

  int get age {
    if (dateOfBirth == null) return 0;
    final now = DateTime.now();
    var value = now.year - dateOfBirth!.year;
    if (now.month < dateOfBirth!.month ||
        (now.month == dateOfBirth!.month && now.day < dateOfBirth!.day)) {
      value--;
    }
    return value;
  }
}

final onboardingData = OnboardingData();

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: AuthService.authStateChanges,
      builder: (context, _) {
        return AuthService.currentUser == null
            ? const WelcomeScreen()
            : const AccountStatusScreen();
      },
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Icon(Icons.favorite_rounded, size: 76),
                const SizedBox(height: 24),
                Text('Campus Connect',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineLarge),
                const SizedBox(height: 12),
                const Text('Meet. Match. Connect.\nVerified adult students only.',
                    textAlign: TextAlign.center),
                const SizedBox(height: 36),
                FilledButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SignUpScreen())),
                  child: const Text('Create account'),
                ),
                const SizedBox(height: 12),
                OutlinedButton(
                  onPressed: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const LoginScreen())),
                  child: const Text('Log in'),
                ),
              ],
            ),
          ),
        ),
      );
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}
class _SignUpScreenState extends State<SignUpScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final formKey = GlobalKey<FormState>();
  bool loading = false;
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> next() async {
    if (!formKey.currentState!.validate()) return;
    setState(() => loading = true);
    try {
      onboardingData.email = email.text.trim().toLowerCase();
      onboardingData.password = password.text;
      await AuthService.signUp(email: onboardingData.email!, password: onboardingData.password!);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AgeVerificationScreen()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create account')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Form(
        key: formKey,
        child: Column(children: [
          TextFormField(controller: email, keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Student email', border: OutlineInputBorder()),
            validator: (v) => v == null || !v.contains('@') ? 'Enter a valid email' : null),
          const SizedBox(height: 16),
          TextFormField(controller: password, obscureText: true,
            decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
            validator: (v) => v == null || v.length < 8 ? 'Use at least 8 characters' : null),
          const Spacer(),
          FilledButton(onPressed: loading ? null : next, child: Text(loading ? 'Creating...' : 'Continue')),
        ]),
      ),
    ),
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  Future<void> login() async {
    setState(() => loading = true);
    try {
      await AuthService.signIn(email: email.text, password: password.text);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const AccountStatusScreen()), (_) => false);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Log in')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        TextField(controller: email, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
        const SizedBox(height: 24),
        FilledButton(onPressed: loading ? null : login, child: Text(loading ? 'Logging in...' : 'Log in')),
      ]),
    ),
  );
}

class AgeVerificationScreen extends StatefulWidget {
  const AgeVerificationScreen({super.key});
  @override
  State<AgeVerificationScreen> createState() => _AgeVerificationScreenState();
}
class _AgeVerificationScreenState extends State<AgeVerificationScreen> {
  DateTime? dob;
  Future<void> pick() async {
    final now = DateTime.now();
    final value = await showDatePicker(context: context, initialDate: DateTime(now.year - 18), firstDate: DateTime(now.year - 100), lastDate: now);
    if (value != null) setState(() => dob = value);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Age verification')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Campus Connect is strictly for students aged 18+.'),
        const SizedBox(height: 24),
        OutlinedButton(onPressed: pick, child: Text(dob == null ? 'Select date of birth' : '${dob!.day}/${dob!.month}/${dob!.year}')),
        const Spacer(),
        FilledButton(onPressed: dob == null ? null : () {
          onboardingData.dateOfBirth = dob;
          if (onboardingData.age < 18) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const UnderageScreen()));
          } else {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const UniversityScreen()));
          }
        }, child: const Text('Continue')),
      ]),
    ),
  );
}

class UnderageScreen extends StatelessWidget {
  const UnderageScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.lock_outline, size: 64),
        const SizedBox(height: 16),
        const Text('Access unavailable', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('Campus Connect is available only to adults aged 18 and above.', textAlign: TextAlign.center),
      ]),
    )),
  );
}

class UniversityScreen extends StatefulWidget {
  const UniversityScreen({super.key});
  @override
  State<UniversityScreen> createState() => _UniversityScreenState();
}
class _UniversityScreenState extends State<UniversityScreen> {
  final universities = const ['Chuka University', 'University of Embu', 'Meru University of Science and Technology'];
  String? selected;
  bool loading = false;
  Future<void> next() async {
    if (selected == null || onboardingData.dateOfBirth == null) return;
    setState(() => loading = true);
    try {
      onboardingData.university = selected;

      // Supabase may require email confirmation before it creates a usable
      // authenticated session. Do not try to write the users row until the
      // email has been verified and a session is available.
      if (AuthService.currentUser == null) {
        if (!mounted) return;
        Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentVerificationScreen()));
        return;
      }

      await AuthService.createUserRecord(dateOfBirth: onboardingData.dateOfBirth!, university: selected!);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => const StudentVerificationScreen()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Select university')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        ...universities.map((u) => RadioListTile<String>(value: u, groupValue: selected, title: Text(u), onChanged: (v) => setState(() => selected = v))),
        const Spacer(),
        FilledButton(onPressed: selected == null || loading ? null : next, child: Text(loading ? 'Saving...' : 'Continue')),
      ]),
    ),
  );
}

class StudentVerificationScreen extends StatelessWidget {
  const StudentVerificationScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Verify student status')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.verified_user_outlined, size: 64),
        const SizedBox(height: 20),
        const Text('Verify your email before your account can proceed.', textAlign: TextAlign.center),
        const SizedBox(height: 20),
        FilledButton(onPressed: () async {
          if (onboardingData.email != null) {
            await AuthService.resendVerificationEmail(onboardingData.email!);
          }
        }, child: const Text('Resend verification email')),
        const SizedBox(height: 12),
        OutlinedButton(onPressed: () async {
          await Supabase.instance.client.auth.refreshSession();
          final user = AuthService.currentUser;
          if (user?.emailConfirmedAt != null && user != null) {
            await AuthService.markEmailVerified();

            // The user row may not exist yet when Supabase required email
            // confirmation during signup. Create it now, after verification.
            if (onboardingData.dateOfBirth != null && onboardingData.university != null) {
              await AuthService.createUserRecord(
                dateOfBirth: onboardingData.dateOfBirth!,
                university: onboardingData.university!,
              );
            }

            if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileSetupScreen()));
          } else if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email is not verified yet.')));
          }
        }, child: const Text('I have verified my email')),
      ]),
    ),
  );
}

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}
class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final name = TextEditingController();
  final bio = TextEditingController();
  bool loading = false;
  Future<void> next() async {
    if (name.text.trim().length < 2) return;
    setState(() => loading = true);
    try {
      await AuthService.saveProfile(displayName: name.text, bio: bio.text);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => const PhotoSetupScreen()));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create your profile')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Display name', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        TextField(controller: bio, maxLength: 500, maxLines: 5, decoration: const InputDecoration(labelText: 'About you', border: OutlineInputBorder())),
        const Spacer(),
        FilledButton(onPressed: loading ? null : next, child: Text(loading ? 'Saving...' : 'Add photos')),
      ]),
    ),
  );
}

class PhotoSetupScreen extends StatefulWidget {
  const PhotoSetupScreen({super.key});
  @override
  State<PhotoSetupScreen> createState() => _PhotoSetupScreenState();
}
class _PhotoSetupScreenState extends State<PhotoSetupScreen> {
  final picker = ImagePicker();
  bool loading = false;
  List<Map<String, dynamic>> photos = [];

  @override
  void initState() { super.initState(); loadPhotos(); }

  Future<void> loadPhotos() async {
    final data = await SocialService.getMyPhotos();
    if (mounted) setState(() => photos = data);
  }

  Future<void> addPhoto() async {
    if (photos.length >= 6) return;
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (image == null) return;
    setState(() => loading = true);
    try {
      await SocialService.uploadProfilePhoto(File(image.path), photos.length);
      await loadPhotos();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> remove(Map<String, dynamic> photo) async {
    await SocialService.deletePhoto(photo);
    await loadPhotos();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Add profile photos')),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        const Text('Add up to 6 photos. Public visibility should remain off until moderation and activation checks are complete.'),
        const SizedBox(height: 16),
        Expanded(
          child: GridView.builder(
            itemCount: photos.length + (photos.length < 6 ? 1 : 0),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10),
            itemBuilder: (_, i) {
              if (i == photos.length) {
                return InkWell(
                  onTap: loading ? null : addPhoto,
                  child: const Card(child: Center(child: loading ? const CircularProgressIndicator() : const Icon(Icons.add_a_photo, size: 48))),
                );
              }
              final photo = photos[i];
              final url = Supabase.instance.client.storage.from('profile-photos').getPublicUrl(photo['image_path']);
              return Stack(children: [
                Positioned.fill(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(url, fit: BoxFit.cover))),
                Positioned(right: 4, top: 4, child: IconButton(onPressed: () => remove(photo), icon: const Icon(Icons.delete))),
              ]);
            },
          ),
        ),
        FilledButton(
          onPressed: photos.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActivationScreen())),
          child: const Text('Continue'),
        ),
      ]),
    ),
  );
}

class ActivationScreen extends StatefulWidget { const ActivationScreen({super.key}); @override State<ActivationScreen> createState()=>_ActivationScreenState(); }
class _ActivationScreenState extends State<ActivationScreen> {
  final senderPhone=TextEditingController();
  final transactionCode=TextEditingController();
  bool loading=false;
  int? amount;
  String? feeError;

  @override
  void initState() {
    super.initState();
    _loadFee();
  }

  Future<void> _loadFee() async {
    try {
      final value = await ManualPaymentService.getActivationFee();
      if (mounted) setState(() => amount = value);
    } catch (e) {
      if (mounted) setState(() => feeError = 'Could not load the activation fee. Please try again.');
    }
  }

  Future<void> submit() async {
    setState(()=>loading=true);
    try {
      await ManualPaymentService.submit(transactionCode: transactionCode.text,senderPhone: senderPhone.text);
      if(!mounted)return;
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const ManualPaymentStatusScreen()));
    } catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
    finally {if(mounted)setState(()=>loading=false);}
  }

  @override
  void dispose(){senderPhone.dispose();transactionCode.dispose();super.dispose();}

  @override
  Widget build(BuildContext context) {
    final fee = amount;
    return Scaffold(
      appBar:AppBar(title:const Text('Activate Campus Connect')),
      body:Padding(
        padding:const EdgeInsets.all(24),
        child:ListView(children:[
          const Icon(Icons.phone_android,size:70),
          const SizedBox(height:16),
          Text('Pay with M-Pesa',textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height:16),
          Text(fee == null ? (feeError ?? 'Loading activation fee...') : 'Send KES $fee to the number below, then submit your M-Pesa transaction code for review.',textAlign:TextAlign.center),
          const SizedBox(height:24),
          Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
            const Text('SEND MONEY TO'),
            const SizedBox(height:8),
            Text(ManualPaymentService.receiverPhone,style:Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height:12),
            Text(fee == null ? 'Amount: —' : 'Amount: KES $fee')
          ]))),
          const SizedBox(height:24),
          TextField(controller:senderPhone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Phone number used to pay',border:OutlineInputBorder())),
          const SizedBox(height:16),
          TextField(controller:transactionCode,textCapitalization:TextCapitalization.characters,decoration:const InputDecoration(labelText:'M-Pesa transaction code',border:OutlineInputBorder())),
          const SizedBox(height:24),
          FilledButton(onPressed:loading || fee == null ? null : submit,child:Text(loading?'Submitting...':'Submit payment for review')),
          const SizedBox(height:12),
          const Text('Never enter your M-Pesa PIN in the app. Only enter the transaction confirmation code.',textAlign:TextAlign.center)
        ])
      )
    );
  }
}
class ManualPaymentStatusScreen extends StatelessWidget { const ManualPaymentStatusScreen({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Payment status')),body:StreamBuilder<List<Map<String,dynamic>>>(stream:ManualPaymentService.myRequests(),builder:(context,snapshot){if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());if(snapshot.data!.isEmpty)return const Center(child:Text('No payment request found.'));final request=snapshot.data!.first;final status=request['status'] as String;final approved=status=='approved';final rejected=status=='rejected';return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(approved?Icons.check_circle_outline:rejected?Icons.error_outline:Icons.hourglass_top,size:72),const SizedBox(height:20),Text(approved?'Payment approved':rejected?'Payment needs attention':'Payment under review',style:Theme.of(context).textTheme.headlineSmall,textAlign:TextAlign.center),const SizedBox(height:12),Text(approved?'Your account has been activated.':rejected?(request['reviewer_note']??'The payment could not be verified.'):'We received your transaction code. Your account will activate automatically after approval.',textAlign:TextAlign.center),const SizedBox(height:24),if(approved)FilledButton(onPressed:()=>Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const AccountStatusScreen()),(_)=>false),child:const Text('Continue'))]))); })); }

class AccountStatusScreen extends StatefulWidget {
  const AccountStatusScreen({super.key});
  @override
  State<AccountStatusScreen> createState() => _AccountStatusScreenState();
}
class _AccountStatusScreenState extends State<AccountStatusScreen> {
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
    future: AuthService.getMyUserRecord(),
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final user = snapshot.data;
      final active = user?['account_status'] == 'active' && user?['activation_paid'] == true;
      return active ? const MainShell() : Scaffold(
        appBar: AppBar(title: const Text('Campus Connect'), actions: [
          FutureBuilder<bool>(future: AuthService.isAdmin(), builder: (_, s) => s.data == true ? IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())), icon: const Icon(Icons.admin_panel_settings_outlined)) : const SizedBox.shrink()),
          IconButton(onPressed: AuthService.signOut, icon: const Icon(Icons.logout)),
        ]),
        body: Center(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(
              user == null
                ? 'Finish onboarding to activate your account.'
                : 'Account: ${user['account_status']}\nVerification: ${user['verification_status']}',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            if (user != null && user['verification_status'] == 'approved' && user['activation_paid'] != true)
              FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ActivationScreen())), child: const Text('Activate with M-Pesa')),
            if (user != null && user['activation_paid'] != true)
              OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ManualPaymentStatusScreen())), child: const Text('Check payment status')),
            if (user != null && user['verification_status'] != 'approved')
              const Text('Your student verification is still being reviewed. Discovery unlocks only after verification and activation are approved.', textAlign: TextAlign.center),
          ]),
        )),
      );
    },
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [DiscoverScreen(), MatchesScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index,
      onDestinationSelected: (i) => setState(() => index = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Discover'),
        NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Matches'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ],
    ),
  );
}

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}
class _DiscoverScreenState extends State<DiscoverScreen> {
  Future<List<Map<String, dynamic>>>? future;
  @override
  void initState() { super.initState(); future = SocialService.getDiscoveryProfiles(); }
  Future<void> swipe(String action) async {
    final list = await future!;
    if (list.isEmpty) return;
    await SocialService.swipe(targetUserId: list.first['user_id'], action: action);
    setState(() => future = SocialService.getDiscoveryProfiles());
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Discover')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (_, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final list = snapshot.data!;
        if (list.isEmpty) return const Center(child: Text('No more verified profiles right now.'));
        final p = list.first;
        final photos = List<String>.from(p['photo_urls'] ?? []);
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Expanded(
              child: Card(
                clipBehavior: Clip.antiAlias,
                child: Column(children: [
                  Expanded(child: photos.isEmpty
                    ? const Center(child: Icon(Icons.person, size: 120))
                    : Image.network(photos.first, width: double.infinity, fit: BoxFit.cover)),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${p['display_name']}, ${p['age']}', style: Theme.of(context).textTheme.headlineSmall),
                      Text(p['university'] ?? ''),
                      const SizedBox(height: 8),
                      Text(p['bio'] ?? ''),
                    ]),
                  ),
                ]),
              ),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              FilledButton.tonal(onPressed: () => swipe('pass'), child: const Icon(Icons.close)),
              FilledButton(onPressed: () => swipe('like'), child: const Icon(Icons.favorite)),
            ]),
          ]),
        );
      },
    ),
  );
}

class MatchesScreen extends StatefulWidget {
  const MatchesScreen({super.key});
  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}
class _MatchesScreenState extends State<MatchesScreen> {
  Future<List<Map<String, dynamic>>>? future;
  @override
  void initState() { super.initState(); future = SocialService.getMatches(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Matches')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (_, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final matches = snapshot.data!;
        if (matches.isEmpty) return const Center(child: Text('No matches yet.'));
        return RefreshIndicator(
          onRefresh: () async => setState(() => future = SocialService.getMatches()),
          child: ListView.builder(
            itemCount: matches.length,
            itemBuilder: (_, i) {
              final match = matches[i];
              return ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(match['display_name'] ?? 'Campus Connect match'),
                subtitle: Text(match['university'] ?? ''),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(
                  matchId: match['match_id'],
                  title: match['display_name'] ?? 'Match',
                ))),
              );
            },
          ),
        );
      },
    ),
  );
}

class ChatScreen extends StatefulWidget {
  final String matchId;
  final String title;
  const ChatScreen({super.key, required this.matchId, required this.title});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  Future<void> send() async {
    await SocialService.sendMessage(matchId: widget.matchId, content: controller.text);
    controller.clear();
  }
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: Column(children: [
      Expanded(
        child: StreamBuilder<List<Map<String, dynamic>>>(
          stream: SocialService.messagesStream(widget.matchId),
          builder: (_, snapshot) {
            final messages = snapshot.data ?? [];
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (_, i) {
                final m = messages[i];
                final mine = m['sender_id'] == AuthService.currentUser?.id;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Card(child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(m['content']),
                  )),
                );
              },
            );
          },
        ),
      ),
      SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Message...', border: OutlineInputBorder()))),
            IconButton(onPressed: send, icon: const Icon(Icons.send)),
          ]),
        ),
      ),
    ]),
  );
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? user;
  Map<String, dynamic>? profile;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final u = await AuthService.getMyUserRecord();
      final p = await AuthService.getMyProfile();
      if (mounted) setState(() { user = u; profile = p; });
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> edit() async {
    final name = TextEditingController(text: profile?['display_name'] ?? '');
    final bio = TextEditingController(text: profile?['bio'] ?? '');
    final form = GlobalKey<FormState>();
    final saved = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Edit profile'),
      content: Form(key: form, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: name, maxLength: 40, decoration: const InputDecoration(labelText: 'Display name'), validator: (v) => (v ?? '').trim().length < 2 ? 'Enter at least 2 characters' : null),
        TextFormField(controller: bio, maxLength: 500, maxLines: 4, decoration: const InputDecoration(labelText: 'Bio')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () async { if (!form.currentState!.validate()) return; await AuthService.saveProfile(displayName: name.text, bio: bio.text); if (context.mounted) Navigator.pop(context, true); }, child: const Text('Save')),
      ],
    ));
    name.dispose(); bio.dispose();
    if (saved == true) load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final name = profile?['display_name'] ?? 'Campus Connect member';
    return Scaffold(
      appBar: AppBar(title: const Text('Profile'), actions: [IconButton(onPressed: edit, icon: const Icon(Icons.edit_outlined)), IconButton(onPressed: AuthService.signOut, icon: const Icon(Icons.logout))]),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          CircleAvatar(radius: 48, child: Text(name.toString().isEmpty ? '?' : name.toString()[0].toUpperCase())),
          const SizedBox(height: 12),
          Text(name, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          Text(user?['university'] ?? '', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          if ((profile?['bio'] ?? '').toString().isNotEmpty) Text(profile!['bio']),
          const SizedBox(height: 20),
          Card(child: Column(children: [
            ListTile(leading: const Icon(Icons.verified_user_outlined), title: const Text('Verification'), subtitle: Text(user?['verification_status'] ?? 'pending')),
            ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Activation'), subtitle: Text(user?['activation_paid'] == true ? 'Active' : 'Payment required')),
          ])),
          const SizedBox(height: 8),
          ListTile(leading: const Icon(Icons.report_outlined), title: const Text('Safety & reporting'), subtitle: const Text('Report or block a member'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SafetyScreen()))),
          ListTile(leading: const Icon(Icons.lock_outline), title: const Text('Privacy & terms'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LegalScreen()))),
        ]),
      ),
    );
  }
}

class SafetyScreen extends StatelessWidget {
  const SafetyScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Safety & reporting')),
    body: ListView(padding: const EdgeInsets.all(20), children: const [
      Text('Keep it respectful', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('Campus Connect is for adults (18+) only. Never share passwords, M-Pesa PINs, or sensitive financial information. Block anyone who makes you uncomfortable and report serious violations.'),
      SizedBox(height: 20),
      Text('Reporting is available from a member profile or chat in the production moderation flow. The current MVP sends reports to the protected backend for review.'),
    ]),
  );
}

class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Privacy & terms')),
    body: ListView(padding: const EdgeInsets.all(20), children: const [
      Text('18+ only', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('You must be at least 18 to use Campus Connect. Accounts may be rejected or suspended when eligibility cannot be verified.'),
      SizedBox(height: 18),
      Text('Privacy', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('We collect only information needed to operate the service, verify eligibility, provide matches and moderate abuse. Do not submit M-Pesa PINs or unnecessary identity documents.'),
      SizedBox(height: 18),
      Text('Consent & conduct', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('Treat matches as real people. Harassment, threats, impersonation, scams, sexual content involving minors, and non-consensual behavior are prohibited and may result in removal.'),
    ]),
  );
}


class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  bool loading = true;
  List<Map<String, dynamic>> payments = [];
  List<Map<String, dynamic>> users = [];
  List<Map<String, dynamic>> photos = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    setState(() => loading = true);
    try {
      final p = await ManualPaymentService.adminPending();
      final u = await Supabase.instance.client.rpc('admin_pending_users');
      final ph = await Supabase.instance.client.rpc('admin_pending_photos');
      if (mounted) setState(() { payments = p; users = (u as List).map((e) => Map<String, dynamic>.from(e)).toList(); photos = (ph as List).map((e) => Map<String, dynamic>.from(e)).toList(); });
    } finally { if (mounted) setState(() => loading = false); }
  }
  Future<void> reviewPayment(Map<String, dynamic> item, bool approve) async {
    await ManualPaymentService.review(requestId: item['id'], approve: approve, note: approve ? 'Approved after manual verification.' : 'Payment could not be verified.');
    await load();
  }
  Future<void> reviewUser(Map<String, dynamic> item, bool approve) async {
    await Supabase.instance.client.rpc('admin_review_user', params: {'target_user_id': item['user_id'], 'approve': approve});
    await load();
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Admin review'), actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
    body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
      onRefresh: load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Text('Student verification', style: Theme.of(context).textTheme.titleLarge),
        if (users.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No users waiting for verification.')),
        ...users.map((u) => Card(child: ListTile(
          title: Text(u['display_name'] ?? u['email'] ?? 'User'),
          subtitle: Text('${u['university']}\n${u['email']}\nStatus: ${u['verification_status']}'),
          isThreeLine: true,
          trailing: Wrap(spacing: 4, children: [
            IconButton(tooltip: 'Approve', onPressed: () => reviewUser(u, true), icon: const Icon(Icons.check_circle_outline)),
            IconButton(tooltip: 'Reject', onPressed: () => reviewUser(u, false), icon: const Icon(Icons.cancel_outlined)),
          ]),
        ))),
        const SizedBox(height: 24),
        Text('Photo moderation', style: Theme.of(context).textTheme.titleLarge),
        if (photos.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No photos waiting for moderation.')),
        ...photos.map((ph) => Card(child: ListTile(
          leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(Supabase.instance.client.storage.from('profile-photos').getPublicUrl(ph['image_path']), width: 54, height: 54, fit: BoxFit.cover)),
          title: Text(ph['display_name'] ?? 'User'),
          subtitle: Text(ph['university'] ?? ''),
          trailing: Wrap(spacing: 4, children: [
            IconButton(tooltip: 'Approve', onPressed: () async { await Supabase.instance.client.rpc('admin_review_photo', params: {'photo_id': ph['id'], 'approve': true}); await load(); }, icon: const Icon(Icons.check_circle_outline)),
            IconButton(tooltip: 'Reject', onPressed: () async { await Supabase.instance.client.rpc('admin_review_photo', params: {'photo_id': ph['id'], 'approve': false}); await load(); }, icon: const Icon(Icons.cancel_outlined)),
          ]),
        ))),
        const SizedBox(height: 24),
        Text('M-Pesa payments', style: Theme.of(context).textTheme.titleLarge),
        if (payments.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No pending payments.')),
        ...payments.map((p) => Card(child: ListTile(
          title: Text('${p['display_name'] ?? 'User'} — KES ${p['amount']}'),
          subtitle: Text('${p['university']}\nTransaction: ${p['transaction_code']}\nPhone: ${p['sender_phone_masked'] ?? 'hidden'}'),
          isThreeLine: true,
          trailing: Wrap(spacing: 4, children: [
            IconButton(tooltip: 'Approve', onPressed: () => reviewPayment(p, true), icon: const Icon(Icons.check_circle_outline)),
            IconButton(tooltip: 'Reject', onPressed: () => reviewPayment(p, false), icon: const Icon(Icons.cancel_outlined)),
          ]),
        ))),
      ]),
    ),
  );
}
